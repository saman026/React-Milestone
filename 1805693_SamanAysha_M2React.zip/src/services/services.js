
import axios from "axios";
import { SERVER_URL,ROLL_NUMBER } from '../utils/constants';


export function serviceCall() {
  return axios.post(`${SERVER_URL}`);
}

export function callDummyAPI(name) {
  return axios.post(
    `${SERVER_URL}${ROLL_NUMBER}/dummy.do?`,
    {},
    {
      headers: { 'Content-Type': 'application/json' },
      params: { name: name },
    }
  );
}


export function addInvo(user) {
  return axios.post(`${SERVER_URL}AddData`, {}, {
    params: user
  })
 
}
 

export function editInvo(user) {
  return axios.post(`${SERVER_URL}EditData`, {}, {
    params: user
  })
 
}
 
export function deleteInvo(user) {
  let doc_id = {doc_id: user.toString()}
  return axios.post(`${SERVER_URL}DeleteData`, {}, {
    params: doc_id
  })
}


export function searchInvo(data) {
  let invoice_no = {invoice_no: data.toString()}
  return axios.get(`${SERVER_URL}GetFormData?invoice_no=${data}`, {}, {
    params: invoice_no
  })
}


export function getDataForCorrespondance(data) {
  return axios.get(`${SERVER_URL}ViewCorrespondance?doc_id=${data}`, {}, {
    params: data
  })
}